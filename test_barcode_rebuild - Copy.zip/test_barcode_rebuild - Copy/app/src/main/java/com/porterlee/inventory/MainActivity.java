/*
 * Copyright (C) 2015-2019 Zebra Technologies Corporation and/or its affiliates
 * All rights reserved.
 */
package com.porterlee.inventory;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.pm.ActivityInfo;
import android.database.sqlite.SQLiteCantOpenDatabaseException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.text.Html;
import android.text.format.DateFormat;
import android.text.method.ScrollingMovementMethod;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.porterlee.inventory.InventoryDatabase.ItemTable;
import com.porterlee.inventory.InventoryDatabase.LocationTable;
import com.symbol.emdk.EMDKManager;
import com.symbol.emdk.EMDKManager.EMDKListener;
import com.symbol.emdk.EMDKManager.FEATURE_TYPE;
import com.symbol.emdk.EMDKResults;
import com.symbol.emdk.barcode.BarcodeManager;
import com.symbol.emdk.barcode.BarcodeManager.ConnectionState;
import com.symbol.emdk.barcode.BarcodeManager.ScannerConnectionListener;
import com.symbol.emdk.barcode.ScanDataCollection;
import com.symbol.emdk.barcode.ScanDataCollection.ScanData;
import com.symbol.emdk.barcode.Scanner;
import com.symbol.emdk.barcode.Scanner.DataListener;
import com.symbol.emdk.barcode.Scanner.StatusListener;
import com.symbol.emdk.barcode.Scanner.TriggerType;
import com.symbol.emdk.barcode.ScannerConfig;
import com.symbol.emdk.barcode.ScannerException;
import com.symbol.emdk.barcode.ScannerInfo;
import com.symbol.emdk.barcode.ScannerResults;
import com.symbol.emdk.barcode.StatusData;
import com.symbol.emdk.barcode.StatusData.ScannerStates;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

//import android.support.annotation.NonNull;
//import android.support.v7.widget.LinearLayoutManager;
//import android.support.v7.widget.RecyclerView;

public class MainActivity extends Activity implements EMDKListener, DataListener, StatusListener, ScannerConnectionListener{

    private EMDKManager emdkManager = null;
    private BarcodeManager barcodeManager = null;
    private Scanner scanner = null;

    private TextView textViewData = null;
    private TextView textViewStatus = null;
    private TextView textViewLocation = null;
    private List<ScannerInfo> deviceList = null;

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    private int scannerIndex = 0; // Keep the selected scanner
    private int scannerIndexDummy = 0;
    private int defaultIndex = 0; // Keep the default scanner
    private int dataLength = 0;
    private String statusString = "";

    private boolean bSoftTriggerSelected = false;
    private boolean bDecoderSettingsChanged = false;
    private boolean bExtScannerDisconnected = false;
    private final Object lock = new Object();

    private static final String DATE_FORMAT = "yyyy/MM/dd kk:mm:ss";
    private static final String TAG = MainActivity.class.getSimpleName();
    private static final String OUTPUT_FILE_HEADER = String.format(Locale.US, "%s|%s|%s|%s|%s|v%s|%d", BuildConfig.FLAVOR, "Inventory", BuildConfig.BUILD_TYPE, BuildConfig.FLAVOR, BuildConfig.BUILD_TYPE, BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE);
    private static final String INVENTORY_DIR_NAME = "Inventory";
    private static final String ARCHIVE_DIR_NAME = "Archives";
    private File outputDir;
    private File internalDir;
    private SQLiteStatement IS_DUPLICATE_STATEMENT;
    private SQLiteStatement LAST_ITEM_BARCODE_STATEMENT;
    private SQLiteStatement TOTAL_ITEM_COUNT;
    private SQLiteStatement TOTAL_LOCATION_COUNT;
    private SQLiteStatement UPDATE_QUANTITY;
    private File outputFile;
    private File databaseFile;
    private File archiveDirectory;
    private boolean changedSinceLastArchive = true;
    private Toast savingToast;
    private SQLiteDatabase mDatabase;
    private AsyncTask<Void, Float, String> saveTask;
    private String barcode;
    private long lastLocationId = -1;
    private String lastLocationBarcode = "";
    private String lastItemBarcode = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        deviceList = new ArrayList<ScannerInfo>();

        EMDKResults results = EMDKManager.getEMDKManager(getApplicationContext(), this);
        if (results.statusCode != EMDKResults.STATUS_CODE.SUCCESS) {
            updateStatus("EMDKManager object request failed!");
            return;
        }

        initializeUI();
        initializeFiles();
        refreshView();
        //initializeDB();
    }

    @Override
    public void onOpened(EMDKManager emdkManager) {
        updateStatus("EMDK open success!");
        this.emdkManager = emdkManager;
        initBarcodeManager();
        enumerateScannerDevices();
        initScanner();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // The application is in foreground
        if (emdkManager != null) {
            initBarcodeManager();
            enumerateScannerDevices();
            initScanner();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // The application is in background
        // Release the barcode manager resources
        deInitScanner();
        deInitBarcodeManager();
    }

    @Override
    public void onClosed() {
        // Release all the resources
        if (emdkManager != null) {
            emdkManager.release();
            emdkManager = null;
        }
        updateStatus("EMDK closed unexpectedly! Please close and restart the application.");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Release all the resources
        if (emdkManager != null) {
            emdkManager.release();
            emdkManager = null;
        }
    }

    @Override
    public void onData(ScanDataCollection scanDataCollection) {
        if ((scanDataCollection != null) && (scanDataCollection.getResult() == ScannerResults.SUCCESS)) {
            ArrayList <ScanData> scanData = scanDataCollection.getScanData();
            for(ScanData data : scanData) {
                barcode = data.getData();
                onBarcodeScanned();
                //updateData("<font color='gray'>" + data.getLabelType() + "</font> : " + data.getData());
            }
        }
    }
    //////////////////////////

    public void initializeUI(){
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR);
        setDefaultOrientation();

        textViewData = (TextView)findViewById(R.id.textViewData);
        textViewStatus = (TextView)findViewById(R.id.textViewStatus);
        textViewData.setSelected(true);
        textViewData.setMovementMethod(new ScrollingMovementMethod());

        textViewLocation = (TextView)findViewById(R.id.textViewLocation);
        textViewLocation.setMovementMethod(new ScrollingMovementMethod());

        recyclerView = (RecyclerView) findViewById(R.id.item_recycler);
        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        // specify an adapter (see also next example)
        //mAdapter = new MyAdapter(myDataset);
        recyclerView.setAdapter(mAdapter);

    }

    public void initializeFiles(){

        archiveDirectory = new File(getFilesDir(), ARCHIVE_DIR_NAME);
        //noinspection ResultOfMethodCallIgnored
        archiveDirectory.mkdirs();
        outputDir = new File(Environment.getExternalStorageDirectory(), INVENTORY_DIR_NAME);
        //noinspection ResultOfMethodCallIgnored
        outputDir.mkdirs();
        outputFile = new File(outputDir.getAbsolutePath(), "data_inventory.txt");
        internalDir = new File(getFilesDir(), INVENTORY_DIR_NAME);
        //noinspection ResultOfMethodCallIgnored
        internalDir.mkdirs();
        databaseFile = new File(internalDir, InventoryDatabase.FILE_NAME);

        try {
            initializeDB();
        } catch (SQLiteCantOpenDatabaseException e) {
            try {
                //System.out.println(databaseFile.exists());
                if (databaseFile.renameTo(File.createTempFile("error", ".db", archiveDirectory))) {
                    Toast.makeText(this, "There was an error loading the inventory file. It has been archived", Toast.LENGTH_SHORT).show();
                } else {
                    databaseLoadError();
                }
            } catch (IOException e1) {
                e1.printStackTrace();
                databaseLoadError();
            }
        }
    }

    public void initializeDB(){
        mDatabase = SQLiteDatabase.openOrCreateDatabase(databaseFile, null);

        ItemTable.create(mDatabase);
        LocationTable.create(mDatabase);

        IS_DUPLICATE_STATEMENT = mDatabase.compileStatement("SELECT COUNT(*) FROM " + ItemTable.NAME + " WHERE " + ItemTable.Keys.LOCATION_ID + " IN ( SELECT " + LocationTable.Keys.ID + " FROM " + LocationTable.NAME + " WHERE " + LocationTable.Keys.BARCODE + " IN ( SELECT " + LocationTable.Keys.BARCODE + " FROM " + LocationTable.NAME + " WHERE " + LocationTable.Keys.ID + " = ? ) ) AND " + ItemTable.Keys.BARCODE + " = ?;");
        LAST_ITEM_BARCODE_STATEMENT = mDatabase.compileStatement("SELECT " + ItemTable.Keys.BARCODE + " FROM " + ItemTable.NAME + " ORDER BY " + ItemTable.Keys.ID + " DESC LIMIT 1;");
        TOTAL_ITEM_COUNT = mDatabase.compileStatement("SELECT COUNT(*) FROM " + ItemTable.NAME);
        TOTAL_LOCATION_COUNT = mDatabase.compileStatement("SELECT COUNT(*) FROM " + LocationTable.NAME);
        UPDATE_QUANTITY = mDatabase.compileStatement("UPDATE " + ItemTable.NAME + " SET " + InventoryDatabase.QUANTITY + " = ? WHERE " + InventoryDatabase.ID + " = ?");

    }

    private void databaseLoadError() {
        //getScanner().setIsEnabled(false);
        new AlertDialog.Builder(MainActivity.this)
                .setCancelable(false)
                .setTitle("Database Load Error")
                .setMessage("There was an error loading the inventory file and it could not be archived.\n\nWould you like to delete the it?\n\nAnswering no will close the app.")
                .setNegativeButton(R.string.action_no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                }).setPositiveButton(R.string.action_yes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (!databaseFile.delete()) {
                    Toast.makeText(MainActivity.this, "The file could not be deleted", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
                Toast.makeText(MainActivity.this, "The file was deleted", Toast.LENGTH_SHORT).show();
                initializeDB();
                //mDatabase = SQLiteDatabase.openOrCreateDatabase(databaseFile, null);
            }
        }).setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                //getScanner().setIsEnabled(true);
            }
        }).create().show();
    }

    public void onBarcodeScanned(){
        if (saveTask != null) {
            //AbstractScanner.onScanComplete(false);
            Toast.makeText(MainActivity.this, "Cannot scan while saving", Toast.LENGTH_SHORT).show();
            return;
        }

        if (barcode == null || barcode.equals("")) {
            //AbstractScanner.onScanComplete(false);
            Toast.makeText(MainActivity.this, "Error scanning barcode: Empty result", Toast.LENGTH_SHORT).show();
            return;
        }

        if (BarcodeType.getBarcodeType(barcode).equals(BarcodeType.Invalid)) {
            //AbstractScanner.onScanComplete(false);
            Toast.makeText(MainActivity.this, "Barcode \"" + barcode + "\" not recognised", Toast.LENGTH_SHORT).show();
            return;
        }

        IS_DUPLICATE_STATEMENT.bindLong(1, lastLocationId);
        IS_DUPLICATE_STATEMENT.bindString(2, barcode);
        final boolean isDuplicate = IS_DUPLICATE_STATEMENT.simpleQueryForLong() > 0;

        if (isDuplicate) {
            //AbstractScanner.onScanComplete(false);
           // getScanner().setIsEnabled(false);
            new AlertDialog.Builder(MainActivity.this)
                    .setCancelable(false)
                    .setTitle("Duplicate item")
                    .setMessage("An item with the same barcode was already scanned, would you still like to add it to the list?")
                    .setNegativeButton(R.string.action_no, null)
                    .setPositiveButton(R.string.action_yes, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            addItem(barcode);
                        }
                    }).setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog) {
                    //getScanner().setIsEnabled(true);
                }
            }).create().show();
            return;
        }

        if (BarcodeType.Item.isOfType(barcode) || BarcodeType.Container.isOfType(barcode)) {
            //AbstractScanner.onScanComplete(true);
            addItem(barcode);
        } else if (BarcodeType.Location.isOfType(barcode)) {
            //AbstractScanner.onScanComplete(true);
            addBarcodeLocation(barcode);
        } else {
            //AbstractScanner.onScanComplete(false);
            Toast.makeText(MainActivity.this, "Barcode \"" + barcode + "\" not recognised", Toast.LENGTH_SHORT).show();
        }
    }

    private void addItem(@NonNull String barcode) {
        if (saveTask != null) return;
        if (lastLocationId == -1) {
            Toast.makeText(this, "A location has not been scanned", Toast.LENGTH_SHORT).show();
            return;
        }

        ContentValues newItem = new ContentValues();
        newItem.put(InventoryDatabase.BARCODE, barcode);
        newItem.put(InventoryDatabase.LOCATION_ID, lastLocationId);
        newItem.put(InventoryDatabase.DESCRIPTION, "");
        newItem.put(InventoryDatabase.TAGS, "");
        newItem.put(InventoryDatabase.DATE_TIME, String.valueOf(formatDate(System.currentTimeMillis())));

        if (mDatabase.insert(ItemTable.NAME, null, newItem) == -1) {
            Utils.vibrate(this.getApplicationContext());
            Log.w(TAG, "Error adding item \"" + barcode + "\" to the inventory");
            Toast.makeText(this, "Error adding item \"" + barcode + "\" to the inventory", Toast.LENGTH_LONG).show();
            return;
        }

//        itemRecyclerAdapter.changeCursor(queryItems());
//        itemRecyclerView.setSelectedItem(itemRecyclerAdapter.getIndexOfBarcode(barcode));
//        changedSinceLastArchive = true;
//        lastItemBarcode = barcode;
//        updateInfo();
        //updateData("Barcode added");
        updateData(barcode);
    }

    private void addBarcodeLocation(@NonNull String barcode) {
        if (saveTask != null) return;
        ContentValues newLocation = new ContentValues();
        newLocation.put(InventoryDatabase.BARCODE, barcode);
        newLocation.put(InventoryDatabase.DESCRIPTION, "");
        newLocation.put(InventoryDatabase.TAGS, "");
        newLocation.put(InventoryDatabase.DATE_TIME, String.valueOf(formatDate(System.currentTimeMillis())));

        long rowID = mDatabase.insert(LocationTable.NAME, null, newLocation);

        if (rowID == -1) {
            Log.w(TAG, "Error adding location \"" + barcode + "\" to the inventory");
            Toast.makeText(this, "Error adding location \"" + barcode + "\" to the inventory", Toast.LENGTH_LONG).show();
            return;
        }

//        locationRecyclerAdapter.changeCursor(queryLocations());
//        locationRecyclerView.setSelectedItem(locationRecyclerAdapter.getIndexOfBarcode(barcode));
        changedSinceLastArchive = true;

        if (!lastLocationBarcode.equals(barcode)) {
            lastLocationId = rowID;
            lastLocationBarcode = barcode;
//            itemRecyclerAdapter.changeCursor(queryItems());
//            itemRecyclerView.setSelectedItem(-1);
        }

//        updateInfo();
        //updateData("Location added");
        updateLocationView(barcode);
    }
    private CharSequence formatDate(long millis) {
        return DateFormat.format(DATE_FORMAT, millis).toString();
    }




    ////////////////////////

    @Override
    public void onStatus(StatusData statusData) {
        ScannerStates state = statusData.getState();
        switch(state) {
            case IDLE:
                statusString = statusData.getFriendlyName()+" is enabled and idle...";
                updateStatus(statusString);
                // set trigger type
                if(bSoftTriggerSelected) {
                    scanner.triggerType = TriggerType.SOFT_ONCE;
                    bSoftTriggerSelected = false;
                } else {
                    scanner.triggerType = TriggerType.HARD;
                }
                // set decoders
                if(bDecoderSettingsChanged) {
                    setDecoders();
                    bDecoderSettingsChanged = false;
                }
                // submit read
                if(!scanner.isReadPending() && !bExtScannerDisconnected) {
                    try {
                        scanner.read();
                    } catch (ScannerException e) {
                        updateStatus(e.getMessage());
                    }
                }
                break;
            case WAITING:
                statusString = "Scanner is waiting for trigger press...";
                updateStatus(statusString);
                break;
            case SCANNING:
                statusString = "Scanning...";
                updateStatus(statusString);
                break;
            case DISABLED:
                statusString = statusData.getFriendlyName()+" is disabled.";
                updateStatus(statusString);
                break;
            case ERROR:
                statusString = "An error has occurred.";
                updateStatus(statusString);
                break;
            default:
                break;
        }
    }

    @Override
    public void onConnectionChange(ScannerInfo scannerInfo, ConnectionState connectionState) {
        String status;
        String scannerName = "";
        String statusExtScanner = connectionState.toString();
        String scannerNameExtScanner = scannerInfo.getFriendlyName();
        if (deviceList.size() != 0) {
            scannerName = deviceList.get(scannerIndex).getFriendlyName();
        }
        if (scannerName.equalsIgnoreCase(scannerNameExtScanner)) {
            switch(connectionState) {
                case CONNECTED:
                    bSoftTriggerSelected = false;
                    synchronized (lock) {
                        initScanner();
                        bExtScannerDisconnected = false;
                    }
                    break;
                case DISCONNECTED:
                    bExtScannerDisconnected = true;
                    synchronized (lock) {
                        deInitScanner();
                    }
                    break;
            }
            status = scannerNameExtScanner + ":" + statusExtScanner;
            updateStatus(status);
        }
        else {
            bExtScannerDisconnected = false;
            status =  statusString + " " + scannerNameExtScanner + ":" + statusExtScanner;
            updateStatus(status);
        }
    }

    private void initScanner() {
        updateStatus("Into initScanner");
        if (scanner == null) {
            updateStatus("scanner NULL");
            if ((deviceList != null) && (deviceList.size() != 0)) {
                if (barcodeManager != null)
                    scanner = barcodeManager.getDevice(deviceList.get(0));
                    updateStatus("Scanner Device Received");
            }
            else {
                updateStatus("Failed to get the specified scanner device! Please close and restart the application.");
                return;
            }
            if (scanner != null) {
                scanner.addDataListener(this);
                scanner.addStatusListener(this);
                try {
                    scanner.enable();
                } catch (ScannerException e) {
                    updateStatus(e.getMessage());
                    deInitScanner();
                }
            }else{
                updateStatus("Failed to initialize the scanner device.");
            }
        }
    }

    private void deInitScanner() {
        if (scanner != null) {
            try{
                scanner.disable();
            } catch (Exception e) {
                updateStatus(e.getMessage());
            }

            try {
                scanner.removeDataListener(this);
                scanner.removeStatusListener(this);
            } catch (Exception e) {
                updateStatus(e.getMessage());
            }

            try{
                scanner.release();
            } catch (Exception e) {
                updateStatus(e.getMessage());
            }
            scanner = null;
        }
    }

    private void initBarcodeManager(){
        barcodeManager = (BarcodeManager) emdkManager.getInstance(FEATURE_TYPE.BARCODE);
        // Add connection listener
        if (barcodeManager != null) {
            barcodeManager.addConnectionListener(this);
        }
        updateStatus("Barcode manager initialized");
    }

    private void deInitBarcodeManager(){
        if (emdkManager != null) {
            emdkManager.release(FEATURE_TYPE.BARCODE);
        }
    }

    private void enumerateScannerDevices() {
        if (barcodeManager != null) {
            List<String> friendlyNameList = new ArrayList<String>();
            int spinnerIndex = 0;
            deviceList = barcodeManager.getSupportedDevicesInfo();
            if ((deviceList != null) && (deviceList.size() != 0)) {
                Iterator<ScannerInfo> it = deviceList.iterator();
                while(it.hasNext()) {
                    ScannerInfo scnInfo = it.next();
                    friendlyNameList.add(scnInfo.getFriendlyName());
                    if(scnInfo.isDefaultScanner()) {
                        defaultIndex = spinnerIndex;
                    }
                    ++spinnerIndex;
                }
                updateStatus("Enumerated Scanner Device");
            }
            else {
                updateStatus("E Failed to get the list of supported scanner devices! Please close and restart the application.");
            }
            List<String> friendlyNameList1 = new ArrayList<String>();
            friendlyNameList1.add("a");
        }
    }

    private void setDecoders() {
        if (scanner != null) {
            try {
                ScannerConfig config = scanner.getConfig();
                config.decoderParams.ean8.enabled = true;
                config.decoderParams.ean13.enabled = true;
                config.decoderParams.code39.enabled= true;
                config.decoderParams.code128.enabled = true;
                scanner.setConfig(config);
            } catch (ScannerException e) {
                updateStatus(e.getMessage());
            }
        }
    }

//    public void softScan(View view) {
//        bSoftTriggerSelected = true;
//        cancelRead();
//    }

    private void cancelRead(){
        if (scanner != null) {
            if (scanner.isReadPending()) {
                try {
                    scanner.cancelRead();
                } catch (ScannerException e) {
                    updateStatus(e.getMessage());
                }
            }
        }
    }

    private void updateStatus(final String status){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                textViewStatus.setText("" + status);
            }
        });
    }

    private void updateData(final String result){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (result != null) {
                    if(dataLength ++ > 100) { //Clear the cache after 100 scans
                        textViewData.setText("");
                        dataLength = 0;
                    }
                    textViewData.append(Html.fromHtml(result));
                    textViewData.append("\n");
                    ((View) findViewById(R.id.scrollViewData)).post(new Runnable()
                    {
                        public void run()
                        {
                            ((ScrollView) findViewById(R.id.scrollViewData)).fullScroll(View.FOCUS_DOWN);
                        }
                    });
                }
            }
        });
    }

    private void updateLocationView(final String result){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (result != null) {
                    if(dataLength ++ > 100) { //Clear the cache after 100 scans
                        textViewData.setText("");
                        dataLength = 0;
                    }
                    textViewLocation.append(Html.fromHtml(result));
                    textViewLocation.append("\n");
                    ((View) findViewById(R.id.scrollViewData)).post(new Runnable()
                    {
                        public void run()
                        {
                            ((ScrollView) findViewById(R.id.scrollViewData)).fullScroll(View.FOCUS_DOWN);
                        }
                    });
                }
            }
        });
    }

    //////////////
    // UI
    /////////////

    public void refreshView(){
        if (lastLocationId == -1){
            // load default DB
        }
        else{
            // load view of location = locationID
        }

    }

    private void setDefaultOrientation(){
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        int height = dm.heightPixels;
        if(width > height){
            setContentView(R.layout.activity_main_landscape);
        } else {
            setContentView(R.layout.activity_main);
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
