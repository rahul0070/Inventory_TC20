package com.porterlee.inventory;

public class Config {
    public static final boolean display_quantity = false;
    public static final String typeContainer_base32Prefix = "A";
    public static final String typeContainer_base64Prefix = "a";
    public static final boolean typeContainer_hasCustodyOf = false;
    public static final boolean typeContainer_hasLabCode = true;
    public static final String[] typeContainer_otherPrefixes = null;
    public static final String typeItem_base32Prefix = "T";
    public static final String typeItem_base64Prefix = "t";
    public static final boolean typeItem_hasCustodyOf = false;
    public static final boolean typeItem_hasLabCode = true;
    public static final String[] typeItem_otherPrefixes = null;
    public static final String typeLocation_base32Prefix = null;
    public static final String typeLocation_base64Prefix = null;
    public static final boolean typeLocation_hasCustodyOf = false;
    public static final boolean typeLocation_hasLabCode = false;
    public static final String[] typeLocation_otherPrefixes = {"L"};
}
