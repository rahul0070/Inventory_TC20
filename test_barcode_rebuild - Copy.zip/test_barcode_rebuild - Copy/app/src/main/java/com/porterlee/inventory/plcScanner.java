package com.porterlee.inventory;

import com.symbol.emdk.EMDKManager;
import com.symbol.emdk.ProfileManager;
import com.symbol.emdk.barcode.BarcodeManager;
import com.symbol.emdk.barcode.BarcodeManager.ScannerConnectionListener;
import com.symbol.emdk.barcode.ScannerInfo;

public class plcScanner implements EMDKManager.EMDKListener, ProfileManager.DataListener, ScannerConnectionListener {
    @Override
    public void onData(ProfileManager.ResultData resultData) {

    }

    @Override
    public void onConnectionChange(ScannerInfo scannerInfo, BarcodeManager.ConnectionState connectionState) {

    }

    @Override
    public void onOpened(EMDKManager emdkManager) {

    }

    @Override
    public void onClosed() {

    }
}
